This application can install public titles such as games, game updates or DLC to your system memory (NAND) or the WiiU formatted USB.

This application is based on "WUP Installer y Mod" by Yardape and the GUI from "Loadiine GX2" sources.

There are 3 versions:
- one work from HBL and HBL channel.
- one work only from HBL Channel.
- one is the WUP Installer GX2 installable channel.

Thanks to:
- Loadiine GX2 team for GUI sources.
- Yardape for installer sources.
- brienj for original rpx port.