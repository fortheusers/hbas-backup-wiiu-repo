U-Paint v3.0 RPX by brienj

Setup:
Put the U-Paint folder from the archive into the install folder of your SD card.  Install the app with the latest wup installer.  Requires sig patching of some kind.

Saving does not work completely yet.  It will only save a picture if one is present on the SD card already.  As a workaround until it gets fixed, copy the drawing folder to the root of the SD card making sure not to overwrite any pictures you have already saved in previous versions.

Instructions:
Touchpad - Use the stylus or your finger in the top-left area to draw on the DRC screen and TV, select colors in the right-hand area
L-Stick: Move view when zoomed in
R-Stick: Up = Zoom In, Down = Zoom Out
A Button: Undo (cycles through the last 10 saved undo pictures to memory)
B Button: Toggles Brush or Spray Mode
Y Button: Toggles Fill (brush becomes completely filled circle) or No-Fill Mode
Minus Button: Decreases Brush Size
Plus Button: Increases Brush Size
LB or RB: Show/Hide Menu
ZL or ZR: Turns on Dropper Mode while held (allows you to assign droppered color to active color)
Home Button: Exit

Painting Mode -
D-PAD U/D: Changes Hardness Level
D-PAD L/R: Changes Flow Level

Color Picker Mode -
D-PAD U/D: Change either R, G, or B (the one with radio button selected) value up/down on the color picker screen

Load/Save Mode -
D-PAD L/R: Change Page Number

The current zoom level, brush size, and brush type are shown in the lower-right area of the DRC screen.  To the left of that, it shows your active color.  Touching this box opens up the color picker menu.  The color picker is like the one in Photoshop.  It defaults to the slider controlling the red value.  You can also either select green or blue with the radio buttons next to them on the right hand side of the menu.  Touching the right side box will set the color change, or touching the red x in the top-right corner will close the menu.  You can change the active color by choosing any of the 10 colors on the right hand side of the main menu.  The last color is the background color which is used when you clear the screen.

The load and save menus allow you to load or save PNG format images.  To load pictures, they must be named any number number between "Picture1.png" and "Picture36.png" and placed in the "sd:/drawings" folder.  The number of load/save slots may be increased in the future, but most likely you will be able to name your pictures or load any that are in the "sd:/drawings" directory in any future update.  Multiple picture formats may also be supported in the future, but the program currently saves to lossless PNG format, which is really the best quality for file size that is possible.

Remember that everything you see on the DRC screen is a representation of the actual FULL picture which is on the TV.  When you are zoomed out on the DRC, you are seeing the full picture that is on the TV, but reduced by 2/3 size, since the DRC is 854 x 480 and the TV is 1280 x 720.  When you are zoomed in, the pixels are identical.

Planned to be added:
Saving and loading palettes
??? - Naming saved pictures or loading any picture in the "sd:/drawings" folder
??? - Design a brush

Special thanks to aliaspider for helping find a problem with the channel.
