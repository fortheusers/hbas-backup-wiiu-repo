Loadiine Forwarder Channel by brienj

Setup:
Put the Loadiine GX2 folder from the archive into the install folder of your SD card.  Install the app with the latest wup installer.  Requires sig patching of some kind.
Replace your current loadiine_gx2.elf file with the one provided in the archive.  The elf file must be placed in sd:/wiiu/apps/loadiine_gx2/loadiine_gx2.elf

Instructions:
After install, select the Loadiine GX2 icon on the system menu with your SD card with the loadiine_gx2.elf inserted.
Profit!

Issues:
Pressing the HOME button on the Loadiine menu will cause Loadiine to just reload.  To exit you must either launch a game and exit from the game or remove your SD card and hit the HOME button, and then press the HOME button again on the blue screen, and then exit from that. I never plan on fixing this issue, just appreciate saving the 5 seconds of time to load this instead of loading HBL and selecting Loadiine from that.