HBL2HBC Forwarder Channel by brienj

Setup:
Put the "WiiU 2 HBC" folder from the archive into the install folder of your SD card.  Install the app with the latest wup installer.  Requires sig patching of some kind.
The forwarder loads hbl2hbc.elf located at sd:/wiiu/apps/hbl2hbc/hbl2hbc.elf

Instructions:
After install, select the "WiiU 2 HBC" icon on the system menu with your SD card with the hbl2hbc.elf inserted.
Profit!
